Reply Assistant, Diagrammed — illustration files

OPEN IN ILLUSTRATOR
  File > Open any .pdf or .svg. Everything is live vector: shapes, arrows and
  text are editable, nothing is a flattened picture. To keep an .ai copy,
  open the PDF and use File > Save As > Adobe Illustrator (.ai).

WHAT'S HERE
  Reply-Assistant-Diagrammed_full.pdf   the whole analysis on one artboard
  Fig1_Evolution        .pdf .svg .png  how the project evolved
  Fig2_Architecture     .pdf .svg .png  how a request moves through the system
  Fig3_Prompt-Flow      .pdf .svg .png  how one message becomes three drafts
  Fig4_Traceability     .pdf      .png  role card -> prompt -> what users see
  1_Brief, Experiment-Log  .pdf  .png   supporting sections
  PNG files are 2x previews for slides or documents.

FONTS (all free on Google Fonts)
  Urbanist (headings), Public Sans (body), JetBrains Mono (labels).
  The PDFs embed them, so they display correctly anywhere. To EDIT text in
  Illustrator without substitution, install the three fonts first.
  The SVGs reference the fonts by name only.

COLORS
  ground #EBE7E1   panel #F4F1EC   box #FBFAF8
  ink #2B2722      muted #6E665D   line #CDC5BA
  accent (teal) #36605F   warning (red) #A8473A
